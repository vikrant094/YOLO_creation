
# coding: utf-8

# In[32]:

import pandas as pd
import os, sys, csv
import glob, errno
import numpy as np
import cv2
import copy


# In[33]:

def read_csv_file(filename):
    csv_file=pd.read_csv(filename, header =None)
    df=pd.DataFrame(csv_file)
    df.columns=df.iloc[0]
   # print(df.columns)
    df=df.drop(df.index[0])
    return df


# In[34]:

def normalizing_image(image_rect_dict, input_size):
    normal_height = input_size[0]
    normal_width = input_size[1]
    normalized_image_rect_dict=[]
    for document in image_rect_dict:
        
        image=document[0]
        image_info=document[1]
        shape_of_Doc = document[1][0]
        rect_info = document[1][1]
        x_factor=normal_width/(document[1][0][1])
        y_factor=normal_height/(document[1][0][0])
        document[1][0][0] = normal_height
        document[1][0][1] = normal_width
        for rect_instance_no in  range(len(document[1][1])):
            
            document[1][1][rect_instance_no][0][0] = document[1][1][rect_instance_no][0][0]*x_factor
            document[1][1][rect_instance_no][0][1] = document[1][1][rect_instance_no][0][1]*y_factor
            
            document[1][1][rect_instance_no][1][0] = document[1][1][rect_instance_no][1][0]*x_factor
            document[1][1][rect_instance_no][1][1] = document[1][1][rect_instance_no][1][1]*y_factor
            
        normalized_image_rect_dict.append(document)
    return normalized_image_rect_dict


# In[35]:

def create_grid(no_of_grid, input_image_size):
    size_of_grid = (int(input_image_size[0]/no_of_grid[0]), int(input_image_size[1]/no_of_grid[1] ))
    list_of_grid_corner=[]
    residual_length = input_image_size[0]
    #
    for row in range(no_of_grid[0]):
        bottom_right_y = 0
        if  residual_length >= size_of_grid[0]:
            bottom_right_y = size_of_grid[0] * (row + 1) 
        else:
            bottom_right_y = size_of_grid[0] * (row) + residual_length 
        
        residual_length = residual_length - size_of_grid[0]
        residual_width = input_image_size[1]
        row_grid=[]
        for col in range(no_of_grid[1]):
            bottom_right_x = 0
            if  residual_width >= size_of_grid[1]:
                bottom_right_x = size_of_grid[1] * (col + 1) 
            else:
                bottom_right_y = size_of_grid[1] * (col) + residual_width 
            residual_width = residual_width - size_of_grid[1]
            top_left_y = size_of_grid[0] * row
            top_left_x = size_of_grid[1] * col
            row_grid.append([(top_left_x, top_left_y), (bottom_right_x, bottom_right_y)])
        list_of_grid_corner.append(row_grid)
    return list_of_grid_corner, size_of_grid         
    


# In[36]:

def isinstance_in_grid(instance, grid):

    mid_point_x = (instance[0][0] + instance[1][0])/2
    mid_point_y = (instance[0][1] + instance[1][1])/2
    

    if (mid_point_x > grid[0][0] and mid_point_x <= grid[1][0]) and (mid_point_y > grid[0][1] and mid_point_y <= grid[1][1]):
        return True
    else:
        return False
    


# In[37]:

def identify_class(instance_class,no_of_class):
    #print("instance_class = ",instance_class)
    one_hot_class_vector= np.zeros((no_of_class,), dtype=int)
    class_list = ["heading", "paragraph", "table", "list", "image"]
    class_index = class_list.index(instance_class)

    one_hot_class_vector[class_index] = 1

    return one_hot_class_vector
    


# In[38]:

def create_label_for_grid(instance, flag, no_of_class, label_training_instance, grid_size):
    object_presence=0

    label = np.zeros((5+no_of_class,), dtype = float)
    if flag == True:
        object_presence = 1
        rect_height = instance[1][0] - instance[0][0] 
        rect_width =  instance[1][1] - instance[0][1]

        b_x = (instance[0][0] + instance[1][0])/2
        b_y = (instance[0][1] + instance[1][1])/2
        b_h = rect_height/grid_size[0]
        b_w = rect_width/grid_size[1]
        one_hot_class_vector = identify_class(instance[2], no_of_class)

        label[0] = b_x
        label[1] = b_y
        label[2] = b_h
        label[3] = b_w
        label[4] = object_presence
        label[5:] = one_hot_class_vector
    #else:
     #   label[1:] = None

    return label
        


# In[39]:

def map_each_object_t_grid(normalized_image_rect_dict, list_of_grid_corner, grid_size, no_of_class, no_of_anchor_box, input_image_size ):
    label_training_set_Y = []
    label_training_set_X = []
    

    for image_index in range(len(normalized_image_rect_dict)):
        image_name = cv2.imread(normalized_image_rect_dict[image_index][0])

        resize_image = cv2.resize(image_name, (input_image_size[1],input_image_size[0]))

        label_training_set_X.append(resize_image) 
  
        total_tru=0;
      #  print("no of instance in image =",len(normalized_image_rect_dict[image_index][1][1]))
        for instance in range(len(normalized_image_rect_dict[image_index][1][1])):
            Instance = normalized_image_rect_dict[image_index][1][1][instance]
            mid_point_x = (Instance[0][0] + Instance[1][0])/2
            mid_point_y = (Instance[0][1] + Instance[1][1])/2
        
            
            
        label_training_instance = []
       # print("size of list_of_grid_corner = ",len(list_of_grid_corner))
        for row_grid_list in list_of_grid_corner:
            label_training_instance_row = []
            for grid in row_grid_list:
                grid_label=[]
                true_content = 0
                for instance in range(len(normalized_image_rect_dict[image_index][1][1])):
                    flag = isinstance_in_grid(normalized_image_rect_dict[image_index][1][1][instance], grid)
                    if flag == True and true_content<no_of_anchor_box:
                        total_tru=total_tru+1
                        true_content = true_content + 1
                        label = create_label_for_grid(normalized_image_rect_dict[image_index][1][1][instance], flag, no_of_class, label_training_instance, grid_size)
                        grid_label.append(label)
                while true_content<no_of_anchor_box:
                    label = create_label_for_grid(None, False, no_of_class, label_training_instance, grid_size)
                    grid_label.append(label)
                    true_content = true_content + 1
                label_training_instance_row.append(grid_label)
            label_training_instance.append(label_training_instance_row)
       # print("total_identified_rectanle in image ",normalized_image_rect_dict[image_index][0], total_tru)
        label_training_set_Y.append(label_training_instance)
    instance_y = np.asarray(label_training_set_Y)
    instance_x = np.asarray(label_training_set_X)
    return instance_x, instance_y
        
    


# In[40]:

def create_train_set(path, file, image_folder, input_image_size, no_of_grid, no_of_class, no_of_anchor_box ):
    os.getcwd()
  #  path=r'D:\imagepro\deep_version\extraction_code'
    os.chdir(path)
    os.getcwd()
    df = read_csv_file(file)
    image_list=df[['Image_name','Image_shape']].drop_duplicates()
   # print( len(image_list), type(image_list))
   # image_folder=r'D:\imagepro\deep_version\rectangled_dataset\went_into_csv'
    os.chdir(image_folder)
    
    
    ###############################
    image_rect_dict=[]
    i=0;
    total_instances=0
    for img in image_list['Image_name']:
    
      
        orig_image= cv2.imread(img)
       # print("orig_image.shape",orig_image.shape)
        image_shape=image_list.iloc[i]['Image_shape']
        image_shape=[int(item) for item in image_list.iloc[i]['Image_shape'][1:][:-1].split(",")]
       
        
        i=i+1;
        rect_midpoint=[]
     
        
        rect_midpoint_index=df.index[df['Image_name'] == img].tolist()
    
        Image_info=[]
        for rect in rect_midpoint_index:
            rect_info=[ df.iloc[rect-1]['Top_left'] , df.iloc[rect-1]['Bottom_Right'], df.iloc[rect-1]['class']]
            Top_left=[int(item) for item in df.iloc[rect-1]['Top_left'][1:][:-1].split(",")]
            Bottom_Right=[int(item) for item in df.iloc[rect-1]['Bottom_Right'][1:][:-1].split(",")]
            
            Image_info.append([Top_left, Bottom_Right, df.iloc[rect-1]['class']])
        
    
        total_instances+=len(Image_info)
        image_rect_dict.append([img,[image_shape, Image_info]])

    
    Image_rect_dict = copy.deepcopy(image_rect_dict)
    normalized_image_rect_dict = normalizing_image(image_rect_dict, input_image_size)
    list_of_grid_corner, grid_size = create_grid(no_of_grid , input_image_size )
    
    instance_x, instance_y = map_each_object_t_grid(normalized_image_rect_dict, list_of_grid_corner, grid_size, no_of_class , no_of_anchor_box , input_image_size  )

    return instance_x, instance_y
    


# In[41]:

instance_x, instance_y = create_train_set(path = r'D:\imagepro\deep_version\extraction_code', file = 'train_set.csv', image_folder = r'D:\imagepro\deep_version\rectangled_dataset\went_into_csv', input_image_size = (1024, 1024), no_of_grid = (8, 8), no_of_class = 5, no_of_anchor_box = 2 )
print("instance_x.shape = ",instance_x.shape)
print("instance_y.shape = ",instance_y.shape)


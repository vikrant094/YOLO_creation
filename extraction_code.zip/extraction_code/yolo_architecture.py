


import training_set_yolo
import pandas as pd
import os, sys, csv
import glob, errno
import numpy as np
import cv2
import copy
from keras.models import Sequential, Model
from keras.layers import Reshape, Activation, Conv2D, Input, MaxPooling2D, BatchNormalization, Flatten, Dense, Lambda
from keras.layers.advanced_activations import LeakyReLU
from keras.callbacks import EarlyStopping, ModelCheckpoint, TensorBoard
from keras.optimizers import SGD, Adam, RMSprop
from keras.layers.merge import concatenate
import matplotlib.pyplot as plt
import keras.backend as K
import tensorflow as tf


train_x, train_y = training_set_yolo.create_train_set(path = r'D:\imagepro\deep_version\extraction_code', file = 'train_set.csv', image_folder = r'D:\imagepro\deep_version\rectangled_dataset\went_into_csv', input_image_size = (1024, 1024), no_of_grid = (8, 8), no_of_class = 5, no_of_anchor_box = 2 )
print(train_x.shape, train_y.shape)


Train_x = train_x[:,:,:,0:1]
Train_y = np.reshape(train_y,(train_y.shape[0],train_y.shape[1],train_y.shape[2], train_y.shape[3]))
print(Train_x[0:1,:,:,:].shape, Train_y[0:1,:,:,:].shape)



labels = ["heading", "paragraph", "table", "list", "image"]


# # In[133]:

#create_architecture
GRID_H, GRID_W, BOX,CLASS= 8,8,2,5
IMAGE_H, IMAGE_W = Train_x.shape[1], Train_x.shape[2] 
input_image = Input(shape=(IMAGE_H, IMAGE_W,1))

print("input_image.shape = ",input_image)
# # Layer 1
x = Conv2D(64, (7,7), strides=(2,2), padding='same', name='conv_1', use_bias=False)(input_image)
x = BatchNormalization(name='norm_1')(x)
x = LeakyReLU(alpha=0.1)(x)
x = MaxPooling2D(pool_size=(2, 2))(x)
print(x.shape)

# Layer 2
x = Conv2D(128, (1,1), strides=(1,1), padding='same', name='conv_2', use_bias=False)(x)
x = BatchNormalization(name='norm_2')(x)
x = LeakyReLU(alpha=0.1)(x)
x = MaxPooling2D(pool_size=(2, 2))(x)
print(x.shape)


# Layer 3
x = Conv2D(256, (3,3), strides=(1,1), padding='same', name='conv_3', use_bias=False)(x)
x = BatchNormalization(name='norm_3')(x)
x = LeakyReLU(alpha=0.1)(x)
x = MaxPooling2D(pool_size=(2, 2))(x)
print(x.shape)


# Layer 4
x = Conv2D(512, (1,1), strides=(2,2), padding='same', name='conv_4', use_bias=False)(x)
x = BatchNormalization(name='norm_4')(x)
x = LeakyReLU(alpha=0.1)(x)
x = MaxPooling2D(pool_size=(2, 2))(x)
print(x.shape)

# Layer 5
x = Conv2D(1024, (3,3), strides=(1,1), padding='same', name='conv_5', use_bias=False)(x)
x = BatchNormalization(name='norm_5')(x)
x = LeakyReLU(alpha=0.1)(x)
x = MaxPooling2D(pool_size=(2, 2))(x)
print(x.shape)
x = Conv2D(BOX * (4 + 1 + CLASS), (1,1), strides=(1,1), padding='same', name='conv_23')(x)
print(x.shape)

output = Reshape((GRID_H*GRID_W, BOX , (4 + 1 + CLASS) ))(x)

print(output.shape)





model = Model([input_image], output)


model.summary()


optimizer = Adam(lr=0.5e-4, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=0.0)


model.compile(loss='mean_squared_error', optimizer=optimizer)




model.fit(Train_x[0:20,:,:,:], Train_y[0:20,:,:,:], epochs=10,batch_size=32)





